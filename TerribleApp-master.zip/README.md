# TerribleApp
### Hummmm, something...

#### Windows only.

To use it,
* First of all, Unzip src.zip.
* Then, run InstallNConfigure.bat.
* After, to launch the app, run start.vbs.
